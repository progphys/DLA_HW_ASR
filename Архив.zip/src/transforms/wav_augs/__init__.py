from src.transforms.wav_augs.gain import Gain
